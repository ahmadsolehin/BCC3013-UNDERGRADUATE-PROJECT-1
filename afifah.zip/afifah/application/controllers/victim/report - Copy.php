<?php defined('BASEPATH') OR exit('No direct script access allowed');

class report extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('victim/report_model','report');
	}

	public function list_report(){

    $id = $this->input->post('id');
	$output = $this->report->list_report($id);
	echo json_encode($output);
}

	public function ajax_add($id)
	{
		$data = array(
					'userId' => $id,
			'name' => $this->input->post('name'),
				'type_of_crime' => $this->input->post('typeofcrime'),
				'location' => $this->input->post('location'),
				'explaination' => $this->input->post('explaination'),
				'date' => $this->input->post('date'),
				'time' => $this->input->post('time'),
			);
		$insert = $this->report->save($data);
		echo json_encode(array("status" => TRUE));
	}

}


