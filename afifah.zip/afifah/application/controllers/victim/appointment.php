<?php defined('BASEPATH') OR exit('No direct script access allowed');

class appointment extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('victim/appointment_model','appointment');
	}

	public function index()
	{
		$this->load->helper('url');
		$this->load->view('victim/appointment_view');
	}

	public function list_appointment(){

    $id = $this->input->post('id');
	$output = $this->appointment->list_appointment($id);
	echo json_encode($output);
}

	public function ajax_add($id)
	{
		$data = array(
					'userId' => $id,
			     'name' => $this->input->post('name'),
				'police_station' => $this->input->post('polis'),
				'location' => $this->input->post('location'),
				'reason' => $this->input->post('reason'),
				'time' => $this->input->post('time'),
				'date' => $this->input->post('date'),
				'status' => 'Pending',
			);
		$insert = $this->appointment->save($data);
		echo json_encode(array("status" => TRUE));
	}

		public function ajax_edit($id)
	{
		$data['id'] = $id;
		$data['output'] = $this->appointment->get_by_id_untuk_Edit($id);
		$this->load->view('victim/edit_appointment', $data);
	}

			public function ajax_update()
	{
		$data = array(
					'userId' => $this->input->post('userId'),
			     'name' => $this->input->post('name'),
				'police_station' => $this->input->post('polis'),
				'location' => $this->input->post('location'),
				'reason' => $this->input->post('reason'),
				'time' => $this->input->post('time'),
				'date' => $this->input->post('date'),
			);
		$this->appointment->update(array('id' => $this->input->post('id')), $data);
		$this->load->view('victim/appointment_view');

	}

		public function ajax_delete($id)
	{
		$this->appointment->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

		public function list_appointment_by_id($id){

	$data['output'] = $this->appointment->get_by_id($id);
	$this->load->view('victim/view_Detail_appointment', $data);
}

}


