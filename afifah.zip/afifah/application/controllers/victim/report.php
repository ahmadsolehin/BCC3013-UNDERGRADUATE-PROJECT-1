<?php defined('BASEPATH') OR exit('No direct script access allowed');

class report extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('victim/report_model','report');
	}

	public function list_report(){

		$id = $this->input->post('id');
		$output = $this->report->list_report($id);
		echo json_encode($output);
	}

	public function list_report_by_id($id){

	$data['output'] = $this->report->get_by_id($id);
	$this->load->view('victim/view_Detail_report', $data);
}

	public function ajax_add($id)
	{
		$data = array(
			'userId' => $id,
			'name' => $this->input->post('name'),
			'type_of_crime' => $this->input->post('typeofcrime'),
			'location' => $this->input->post('location'),
			'explaination' => $this->input->post('explaination'),
			'date' => $this->input->post('date'),
			'time' => $this->input->post('time'),
			'status' => 'Pending',
			);
		$insert = $this->report->save($data);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_edit($id)
	{
		$data = $this->report->get_by_id_untuk_Edit($id);
		echo json_encode($data);
	}

		public function ajax_update($id)
	{
		$data = array(
			'userId' => $id,
			'name' => $this->input->post('name'),
			'type_of_crime' => $this->input->post('typeofcrime'),
			'location' => $this->input->post('location'),
			'explaination' => $this->input->post('explaination'),
			'date' => $this->input->post('date'),
			'time' => $this->input->post('time'),
			);
		$this->report->update(array('id' => $this->input->post('id')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_delete($id)
	{
		$this->report->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

}


