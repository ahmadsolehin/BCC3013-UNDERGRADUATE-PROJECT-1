<?php defined('BASEPATH') OR exit('No direct script access allowed');

class appointment extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('admin/appointment_model','appointment');
	}

	public function index()
	{
		$this->load->helper('url');
		$this->load->view('admin/appointment_view');
	}

	public function ajax_list()
	{
		$list = $this->appointment->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $appointment) {
			$no++;
			$row = array();
			$row[] = $appointment->name;
			$row[] = $appointment->date;
			$row[] = $appointment->police_station;
			$row[] = $appointment->reason;
			$row[] = $appointment->status;

			//add html for action
			$row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_person('."'".$appointment->id."'".')"><i class="glyphicon glyphicon-pencil"></i> Edit</a>
			<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Delete" onclick="delete_person('."'".$appointment->id."'".')"><i class="glyphicon glyphicon-trash"></i> Delete</a>
			<a class="btn btn-sm btn-default" href="javascript:void(0)" title="View" onclick="view_person('."'".$appointment->id."'".')"><i class="glyphicon glyphicon-file"></i> View</a>';

			$data[] = $row;
		}

		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->appointment->count_all(),
			"recordsFiltered" => $this->appointment->count_filtered(),
			"data" => $data,
			);
		//output to json format
		echo json_encode($output);
	}

		public function ajax_edit($id)
	{
		$data['id'] = $id;
		$data['output'] = $this->appointment->get_by_id_untuk_Edit($id);
		$this->load->view('admin/edit_appointment', $data);
	}


	public function ajax_update()
	{
		$data = array(
			'userId' => $this->input->post('userId'),
			'name' => $this->input->post('name'),
			'police_station' => $this->input->post('polis'),
			'location' => $this->input->post('location'),
			'reason' => $this->input->post('reason'),
			'time' => $this->input->post('time'),
			'date' => $this->input->post('date'),
			'status' => $this->input->post('status'),
			);
		$this->appointment->update(array('id' => $this->input->post('id')), $data);
		$this->load->view('admin/appointment_view');
	}

			public function ajax_delete($id)
	{
		$this->appointment->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}


	public function list_appointment_by_id($id){

	$data['output'] = $this->appointment->get_by_id($id);
	$this->load->view('admin/view_Detail_appointment', $data);
}

	


	
}


