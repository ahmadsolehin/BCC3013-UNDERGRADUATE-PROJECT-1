<?php defined('BASEPATH') OR exit('No direct script access allowed');

class home extends CI_Controller {

      public function __construct(){
        parent::__construct();
        $this->load->model('User_model', 'user_model', TRUE);
        $this->load->library('form_validation');    
        $this->form_validation->set_error_delimiters('<div style="color:red;" class="error">', '</div>');
    }   

	public function index()
	{
		$this->load->view('login_page');
	}

    public function load_RegisterForm()
    {
        $this->load->view('register');
    }

        public function logout()
    {
        $this->session->sess_destroy();
        redirect(site_url().'home/index/');
    }

	public function login()
    {
        $this->form_validation->set_rules('username', 'username', 'required');    
        $this->form_validation->set_rules('password', 'Password', 'required'); 

        if($this->form_validation->run() == FALSE) {

            $this->load->view('header');
            $this->load->view('login_page');

        }else{

            $post = $this->input->post();  
            $clean = $this->security->xss_clean($post);

            $userInfo = $this->user_model->checkLogin($clean);

            if ($userInfo->status == 'victim') { //kalau role = admin

                 foreach($userInfo as $key=>$val){
                    $this->session->set_userdata($key, $val);
                }
                redirect(site_url().'home/load_Victim_menu');

             }

             if ($userInfo->status == 'admin') { //kalau role = admin

                 foreach($userInfo as $key=>$val){
                    $this->session->set_userdata($key, $val);
                }
                redirect(site_url().'home/load_Admin_menu');

             }else{ // kalau role = lain

                if(!$userInfo){
                    $this->session->set_flashdata('flash_message', 'The login was unsucessful');
                    redirect(site_url().'home/login');
                }                
                
             }
            
        }

    }

       public function register()
    {

        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('ic', 'Ic', 'required');    
        $this->form_validation->set_rules('working', 'Working', 'required');    
        $this->form_validation->set_rules('address', 'Address', 'required');
        $this->form_validation->set_rules('house', 'House no', 'required');
        $this->form_validation->set_rules('office', 'Office no', 'required');
        $this->form_validation->set_rules('hp', 'Hp no', 'required');
        $this->form_validation->set_rules('gender', 'Gender', 'required');
        $this->form_validation->set_rules('dob', 'Date of birth', 'required');
        $this->form_validation->set_rules('nationality', 'Nationality', 'required');

        if ($this->form_validation->run() == FALSE) {   
            $this->load->view('header');
            $this->load->view('register');
        }else{                

                $clean = $this->security->xss_clean($this->input->post(NULL, TRUE));
                $id = $this->user_model->insertUser($clean); 
                $this->session->set_flashdata('flash_message', 'Your account has been created!!');
                redirect(site_url().'home/login');           
        }
    }

    public function load_Admin_menu()
    {
        $this->load->view('admin/admin_mainmenu');
    }

    public function load_Victim_menu()
    {
        $this->load->view('victim/victim_mainmenu');
    }

        public function load_Profile()
    {
        $this->load->view('view_profile');
    }

    public function check_Ic_available()
    {
        $ic = $this->input->post('ic');
        $data = $this->user_model->check_Ic_available($ic);

        if ($data == true) {
            echo '1';
        }
        else{
            echo '0';
        }
    }

            public function ajax_edit($id)
    {
        $data['id'] = $id;
        $data['output'] = $this->user_model->get_by_id_untuk_Edit($id);
        $this->load->view('edit_profile', $data);
    }

    public function edit_ubah()
    {
                $data = array(
                'username' => $this->input->post('username'),
                'password' => $this->input->post('password'),
                'name' => $this->input->post('name'),

                'ic' => $this->input->post('ic'),
                'working' => $this->input->post('working'),
                'address' => $this->input->post('address'),

                'house' => $this->input->post('house'),
                'office' => $this->input->post('office'),
                'hp' => $this->input->post('hp'),

                'gender' => $this->input->post('gender'),
                'nationality' => $this->input->post('nationality'),
                'birthday' => $this->input->post('date'),
            );
        $this->user_model->update(array('id' => $this->input->post('id')), $data);
        echo json_encode(array("status" => TRUE));
    }
}
