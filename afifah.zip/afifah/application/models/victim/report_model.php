<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class report_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function list_report($id){
		$this->db->from('report');
		$this->db->where('userId',$id);
		$query = $this->db->get();
		return $query->result();
	}

	public function save($data)
	{
		$this->db->insert('report', $data);
		return $this->db->insert_id();
	}

	public function update($where, $data)
	{
		$this->db->update('report', $data, $where);
		return $this->db->affected_rows();
	}

		public function get_by_id_untuk_Edit($id)
	{
		$this->db->from('report');
		$this->db->where('id',$id);
		$query = $this->db->get();

		return $query->row();
	}

	public function get_by_id($id)
	{
		$this->db->from('report');
		$this->db->where('id',$id);
		$query = $this->db->get();
		if($query->num_rows() > 0) {
			$results = $query->result();
		}
		return $results;
	}

	public function delete_by_id($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('report');
	}

}