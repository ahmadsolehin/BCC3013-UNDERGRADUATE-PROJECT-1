<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class appointment_model extends CI_Model {

		public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function list_appointment($id){
	    $this->db->from('appointment');
        $this->db->where('userId',$id);
        $query = $this->db->get();
        return $query->result();
	}

		public function save($data)
	{
		$this->db->insert('appointment', $data);
		return $this->db->insert_id();
	}

	      public function get_by_id_untuk_Edit($id)
      {
        $this->db->from('appointment');
        $this->db->where('id',$id);
        return $this->db->get()->result(); //result bole view data array kt controller
      }

		public function update($where, $data)
	{
		$this->db->update('appointment', $data, $where);
		return $this->db->affected_rows();
	}

		public function delete_by_id($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('appointment');
	}

		public function get_by_id($id)
	{
		$this->db->from('appointment');
		$this->db->where('id',$id);
		$query = $this->db->get();
		if($query->num_rows() > 0) {
			$results = $query->result();
		}
		return $results;
	}


}