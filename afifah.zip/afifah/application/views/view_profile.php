<style type="text/css">

  #buangLine{
    border: none;
    background-color: transparent;
    resize: none;
    outline: none;
  }

</style>

  <!-- Horizontal Form -->
  <div class="box-header with-border">
    <div class="col-md-6">
      <h3 class="box-title">View Profile</h3>
    </div>

    <div class="col-md-6">
      <span class="pull-right">

        <button class="btn btn-primary" id = "butangEdit"><i class="fa fa-pencil"> </i> Edit</button>

      </span>
    </div>
  </div>
  <!-- /.box-header -->
  <!-- form start -->


  <form class="form-horizontal" id="dataCryo" method="post" enctype="multipart/form-data">

    <div class="box-body">

           <div class="form-group">
        <label for="" class="col-sm-2 control-label">Username : </label>

        <div class="col-sm-6">
          <h5 class="col-sm-6 "><?php echo $this->session->userdata('username');?></h5>
        </div>
      </div>

             <div class="form-group">
        <label for="" class="col-sm-2 control-label">Password : </label>

        <div class="col-sm-6">
          <h5 class="col-sm-6 "><?php echo $this->session->userdata('password');?></h5>
        </div>
      </div>


      <div class="form-group">
        <label for="" class="col-sm-2 control-label">Name : </label>

        <div class="col-sm-6">
          <h5 class="col-sm-6 "><?php echo $this->session->userdata('name');?></h5>
        </div>
      </div>

      <div class="form-group">
        <label for="" class="col-sm-2 control-label">Ic : </label>

        <div class="col-sm-6">
          <h5 class="col-sm-6 "><?php echo $this->session->userdata('ic');?></h5>
        </div>
      </div>

      <div class="form-group">
        <label for="" class="col-sm-2 control-label">Working : </label>

        <div class="col-sm-6">
          <h5 class="col-sm-6 "><?php echo $this->session->userdata('working');?></h5>
        </div>
      </div>


      <div class="form-group">
        <label for="" class="col-sm-2 control-label">Address : </label>

        <div class="col-sm-6">
          <h5 class="col-sm-6 "><?php echo $this->session->userdata('address');?></h5>
        </div>
      </div>


      <div class="form-group">
        <label for="" class="col-sm-2 control-label">House : </label>

        <div class="col-sm-6">
          <h5 class="col-sm-6 "><?php echo $this->session->userdata('house');?></h5>
        </div>
      </div>

      <div class="form-group">
        <label for="" class="col-sm-2 control-label">Office : </label>

        <div class="col-sm-6">
          <h5 class="col-sm-6 "><?php echo $this->session->userdata('office');?></h5>
        </div>
      </div>

       <div class="form-group">
        <label for="" class="col-sm-2 control-label">Hp : </label>

        <div class="col-sm-6">
          <h5 class="col-sm-6 "><?php echo $this->session->userdata('hp');?></h5>
        </div>
      </div>

             <div class="form-group">
        <label for="" class="col-sm-2 control-label">Gender : </label>

        <div class="col-sm-6">
          <h5 class="col-sm-6 "><?php echo $this->session->userdata('gender');?></h5>
        </div>
      </div>

             <div class="form-group">
        <label for="" class="col-sm-2 control-label">Birthday : </label>

        <div class="col-sm-6">
          <h5 class="col-sm-6 "><?php echo $this->session->userdata('birthday');?></h5>
        </div>
      </div>

             <div class="form-group">
        <label for="" class="col-sm-2 control-label">Nationality : </label>

        <div class="col-sm-6">
          <h5 class="col-sm-6 "><?php echo $this->session->userdata('nationality');?></h5>
        </div>
      </div>




  </div>
</form>
<!-- /.box -->



<script>
$(document).ready(function () {

  $('#butangEdit').unbind('click').click(function () {
    
    $.ajax({
        url : "<?php echo site_url('home/ajax_edit/')?>/" +<?php echo $this->session->userdata('id');?>,
      type: "GET",
        success: function(result)
        {
         $('#haha').empty().html(result).fadeIn('slow');
       },
       error: function (jqXHR, textStatus, errorThrown)
       {
        alert('Error get data from ajax');
      }
    });

  })
})
</script>

