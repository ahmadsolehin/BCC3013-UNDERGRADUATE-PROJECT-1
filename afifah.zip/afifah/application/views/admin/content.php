<div id = "haha">           

		<script src="<?php echo base_url('assets/test/js-image-slider.js')?>"></script>
	
		<link href="<?php echo base_url('assets/test/js-image-slider.css')?>" rel="stylesheet">

		<div id="sliderFrame">
			<div id="slider">
				<a href="" target="_blank">
					<img src="<?php echo base_url('images/crime.jpg'); ?>" alt="#cap1" />
				</a>
				<img id="image1" src="<?php echo base_url('images/download.png'); ?>" alt="Welcome to Our Site."/>
				<img id="image1" src="<?php echo base_url('images/Theft-crime.jpg'); ?>" alt="Report any crime.."/>
				<img id="image1" src="<?php echo base_url('images/crime.jpg'); ?>" alt="Many type of crime."/>
				<img id="image1" src="<?php echo base_url('images/crime.jpg'); ?>" />
			</div>
			<div style="display: none;">
				<div id="cap1">
					Welcome to <a href="http://www.google.com/">E-CRIME.com</a>.
				</div>
				<div id="cap2">
					<em>HTML</em> caption. Link to <a href="http://www.google.com/">Google</a>.
				</div>
			</div>
		</div>


</div>
