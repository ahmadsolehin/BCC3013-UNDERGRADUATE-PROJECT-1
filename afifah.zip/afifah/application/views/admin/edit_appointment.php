
<link href="<?php echo base_url('assets/css/bootstrap-datepicker3.min.css')?>" rel="stylesheet">
<script src="<?php echo base_url('assets/js/bootstrap-datepicker.min.js')?>"></script>

<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/prettify/r298/run_prettify.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap3-dialog/1.34.9/css/bootstrap-dialog.min.css" rel="stylesheet" type="text/css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap3-dialog/1.34.9/js/bootstrap-dialog.min.js"></script>

<div class="box-header with-border">
  <div class="col-md-6">
    <h3 class="box-title">Edit Appointment</h3>
  </div>

  <div class="col-md-6">
    <span class="pull-right">
      <button class="btn btn-default" id = "butangBack"><i class="fa fa-arrow-left"> </i> Back</button>
    </span>
  </div>
</div>
<!-- /.box-header -->
<!-- form start -->

<?php foreach ($output as $data): ?>

  <form class="form-horizontal" id="dataCryo" method="post" enctype="multipart/form-data">
    <input type="hidden" value="<?php echo $id; ?>" name="id"/> 
    <input type="hidden" value="<?php echo $data->userId; ?>" name="userId"/> 

    <div class="box-body">

      <div class="form-group">
        <label for="" class="col-sm-2 control-label">Name : </label>

        <div class="col-sm-6">
          <input type="text" class="form-control" value = "<?php echo $data->name ?>" name = "name">
        </div>
      </div>


      <div class="form-group">
        <label for="" class="col-sm-2 control-label">Date : </label>
        <div class="col-sm-6">
          <input type="text" value = "<?php echo $data->date; ?> "placeholder="" class="form-control" id = "datepicker" name="date">
        </div>
      </div>

      <div class="form-group">
        <label for="" class="col-sm-2 control-label">Time : </label>
        <div class="col-sm-6">
          <input type="text" value = "<?php echo $data->time; ?> " class="form-control" name="time">
        </div>
      </div>

      <div class="form-group">
        <label for="" class="col-sm-2 control-label">Reason : </label>
        <div class="col-sm-6">
          <input type="text" value = "<?php echo $data->reason; ?> " class="form-control" name="reason">
        </div>
      </div>

      <div class="form-group">
        <label for="" class="col-sm-2 control-label">Location : </label>
        <div class="col-sm-6">
          <select name = "location" id = "lokasi" class="form-control">
          </select>
        </div>
      </div>




      <div class="form-group">
        <label for="" class="col-sm-2 control-label">Police Station : </label>
        <div class="col-sm-6">
          <textarea class="form-control" rows="3" id = "polis" name = "polis"><?php echo $data->police_station; ?></textarea>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-sm-2">Status</label>
        <div class="col-md-6">
          <select id = "selstatus" name="status" class="form-control">

          </select>
        </div>
      </div>



      <script type="text/javascript">

        var xray = ['Success', 'Reject', 'Pending'];

        for (var i = 0; i < xray.length; i++) {

          var select = '';
          if(xray[i]=='<?php echo $data->status; ?>'){
            select = 'selected';
          }

          var ayam = '<option value = "'+xray[i]+'" '+select+'> '+xray[i]+' </option>';
          $('#selstatus').append(ayam);
        }

      </script>



      <script type="text/javascript">

        var month = ['KUANTAN', 'BENTONG', 'CAMERON', 'JERANTUT', 'LIPIS', 'MARAN', 'PEKAN', 'RAUB', 'ROMPIN', 'BERA'];

        for (var i = 0; i < month.length; i++) {

          var select = '';
          if(month[i]=='<?php echo $data->location; ?>'){
            select = 'selected';
          }

          var a = '<option value = "'+month[i]+'" '+select+'> '+month[i]+' </option>';
          $('#lokasi').append(a);
        }

      </script>


    <?php endforeach; ?>


    <div class="form-group">
      <div class="col-sm-offset-2 col-sm-10">
        <label> 
          <input type="submit" class="btn btn-primary" id = "btnSubmitCryo"value="Save" /> 
        </label>
      </div>
    </div>

  </div>
</form>
<!-- /.box -->



<script>
  $(document).ready(function () {

    $('#butangBack').unbind('click').click(function () {
      $.ajax({
        url : "<?php echo site_url('admin/appointment')?>",
        success: function (result) {
          $('#haha').empty().html(result).fadeIn('slow');
        }});
    })
  })
</script>


<script type="text/javascript">

  $("form#dataCryo").submit(function(){

    var formData = new FormData($(this)[0]);
    url = "<?php echo site_url('admin/appointment/ajax_update')?>";

    $.ajax({
      url: url,
      type: 'POST',
      data: formData,
      async: false,
      success: function (result) {

        var dialog = new BootstrapDialog.show({
          message: 'Data has been edit..'
        });

        dialog.getModalHeader().css('color', '#fff');
        dialog.getModalHeader().css('background-color', '#337ab7');
        dialog.open();

        $('#haha').empty().html(result).fadeIn('slow');

      },
      cache: false,
      contentType: false,
      processData: false
    });

    return false;
  });



</script>







<script type="text/javascript">

//datepicker
$(document).ready(function(){
    //datepicker
    $('#datepicker').datepicker({
      autoclose: true,
      format: "yyyy-mm-dd",
      todayHighlight: true,
      orientation: "top auto",
      todayBtn: true,
      todayHighlight: true,  
    });
  })


</script>






<script type="text/javascript">

  $('form#dataCryo').on('keyup keypress', function(e) {
    var keyCode = e.keyCode || e.which;
    if (keyCode === 13) { 
      e.preventDefault();
      return false;
    }
  });

  $('.form-control').keydown(function (e) {
   if (e.which === 13) {
     var index = $('.form-control').index(this) + 1;
     $('.form-control').eq(index).focus();
   }
 });

</script>












<script type="text/javascript">


 $(document).on('change','#lokasi',function(){

  if($(this).val() == "KUANTAN")
  {
    $('#polis').empty().append('Ibupejabat Polis Daerah Kuantan Polis Diraja Malaysia Jalan Mahkota 25000 Kuantan, Pahang.');
  }
  else if($(this).val() == "BENTONG")
  {
    $('#polis').empty().append('Ibupejabat Polis Daerah Bentong Jalan Anuar Polis Diraja Malaysia 28700 Bentong, Pahang');
  }
  else if($(this).val() == "CAMERON")
  {
    $('#polis').empty().append('Ibupejabat Polis Daerah Cameron Highland Tanah Rata Polis Diraja Malaysia 39000 Pahang.');
  }
  else if($(this).val() == "JERANTUT")
  {
    $('#polis').empty().append('Ibupejabat Polis Daerah Jerantut Polis Diraja Malaysia 27000 Jerantut,Pahang.');
  }
  else if($(this).val() == "LIPIS")
  {
    $('#polis').empty().append('Ibupejabat Polis Daerah Kuala Lipis Polis Diraja Malaysia 27200 Kuala Lipis Pahang.');
  }
  else if($(this).val() == "MARAN")
  {
    $('#polis').empty().append('Ibupejabat Polis Daerah Maran Polis Diraja Malaysia 26500 Maran,Pahang.');
  }
  else if($(this).val() == "PEKAN")
  {
    $('#polis').empty().append('Ibupejabat Polis Daerah Daerah Pekan Polis Diraja Malaysia 26600 Pekan, Pahang.');
  }
  else if($(this).val() == "RAUB")
  {
    $('#polis').empty().append('Ibupejabat Polis Daerah Daerah Raub Polis Diraja Malaysia 27600 Raub Pahang');
  }
  else if($(this).val() == "ROMPIN")
  {
    $('#polis').empty().append('Ibupejabat Polis Daerah Rompin Polis Diraja Malaysia 26800 K. Rompin,Rompin, Pahang.');
  }
  else if($(this).val() == "BERA")
  {
    $('#polis').empty().append('Ibupejabat Polis Daerah Bera Polis Diraja Malaysia 28300, Bera.');
  }
});


</script>