
<link href="<?php echo base_url('assets/css/bootstrap-datepicker3.min.css')?>" rel="stylesheet">
<script src="<?php echo base_url('assets/js/bootstrap-datepicker.min.js')?>"></script>

<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/prettify/r298/run_prettify.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap3-dialog/1.34.9/css/bootstrap-dialog.min.css" rel="stylesheet" type="text/css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap3-dialog/1.34.9/js/bootstrap-dialog.min.js"></script>



<script type="text/javascript">

//datepicker
$(document).ready(function(){
    //datepicker
    $('#xxx').datepicker({
      autoclose: true,
      format: "yyyy-mm-dd",
      todayHighlight: true,
      orientation: "top auto",
      todayBtn: true,
      todayHighlight: true,  
    });
  })


</script>

<div class="box-header with-border">
  <div class="col-md-6">
    <h3 class="box-title">Edit Profile</h3>
  </div>

  <div class="col-md-6">
    <span class="pull-right">
      <button class="btn btn-default" id = "butangBack"><i class="fa fa-arrow-left"> </i> Back</button>
    </span>
  </div>
</div>
<!-- /.box-header -->
<!-- form start -->

<?php foreach ($output as $data): ?>

  <form class="form-horizontal" id="dataCryo" method="post" enctype="multipart/form-data">
    <input type="hidden" value="<?php echo $id; ?>" name="id"/> 

    <div class="box-body">

     <div class="form-group">
      <label for="" class="col-sm-2 control-label">Username : </label>

      <div class="col-sm-6">
        <input type="text" class="form-control" value = "<?php echo $data->username ?>" name = "username">
      </div>
    </div>

    <div class="form-group">
      <label for="" class="col-sm-2 control-label">Password : </label>

      <div class="col-sm-6">
        <input type="text" class="form-control" value = "<?php echo $data->password ?>" name = "password">
      </div>
    </div>

    <div class="form-group">
      <label for="" class="col-sm-2 control-label">Name : </label>

      <div class="col-sm-6">
        <input type="text" class="form-control" value = "<?php echo $data->name ?>" name = "name">
      </div>
    </div>


    <div class="form-group">
      <label for="" class="col-sm-2 control-label">Ic : </label>
      <div class="col-sm-6">
        <input type="text" value = "<?php echo $data->ic; ?> "placeholder="" class="form-control" id = "ic" name="ic">
      </div>
    </div>

    <div class="form-group">
      <label for="" class="col-sm-2 control-label">Working : </label>
      <div class="col-sm-6">
        <input type="text" value = "<?php echo $data->working; ?> " class="form-control" name="working">
      </div>
    </div>

    <div class="form-group">
      <label for="" class="col-sm-2 control-label">Address : </label>
      <div class="col-sm-6">
        <textarea class="form-control" rows="3" id = "" name = "address"><?php echo $data->address; ?></textarea>
      </div>
    </div>

    <div class="form-group">
      <label for="" class="col-sm-2 control-label">House : </label>
      <div class="col-sm-6">
        <input type="text" value = "<?php echo $data->house; ?> " class="form-control" name="house">
      </div>
    </div>

    <div class="form-group">
      <label for="" class="col-sm-2 control-label">Office : </label>
      <div class="col-sm-6">
        <input type="text" value = "<?php echo $data->office; ?> " class="form-control" name="office">
      </div>
    </div>

    <div class="form-group">
      <label for="" class="col-sm-2 control-label">Hp : </label>
      <div class="col-sm-6">
        <input type="text" value = "<?php echo $data->hp; ?> " class="form-control" name="hp">
      </div>
    </div>

    <div class="form-group">
      <label for="" class="col-sm-2 control-label">Gender : </label>
      <div class="col-sm-6">
        <select name = "gender" id = "gender" class="form-control">
        </select>
      </div>
    </div>

    <div class="form-group">
      <label for="" class="col-sm-2 control-label">Birthday : </label>
      <div class="col-sm-6">
        <input type="text" value = "<?php echo $data->birthday; ?> " id = "xxx" class="form-control" name="date">
      </div>
    </div>

    <div class="form-group">
      <label for="" class="col-sm-2 control-label">Nationality : </label>
      <div class="col-sm-6">
        <input type="text" value = "<?php echo $data->nationality; ?> " class="form-control" name="nationality">
      </div>
    </div>



    <script type="text/javascript">

      var month = ['Male', 'Female'];

      for (var i = 0; i < month.length; i++) {

        var select = '';
        if(month[i]=='<?php echo $data->gender; ?>'){
          select = 'selected';
        }

        var a = '<option value = "'+month[i]+'" '+select+'> '+month[i]+' </option>';
        $('#gender').append(a);
      }

    </script>


  <?php endforeach; ?>


  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <label> 
        <input type="submit" class="btn btn-primary" id = "btnSubmitCryo"value="Save" /> 
      </label>
    </div>
  </div>

</div>
</form>
<!-- /.box -->



<script>
  $(document).ready(function () {

    $('#butangBack').unbind('click').click(function () {
      $.ajax({
        url : "<?php echo site_url('home/load_profile')?>",
        success: function (result) {
          $('#haha').empty().html(result).fadeIn('slow');
        }});
    })
  })
</script>


<script type="text/javascript">

  $("form#dataCryo").submit(function(){

    var formData = new FormData($(this)[0]);
    url = "<?php echo site_url('home/edit_ubah')?>";

    $.ajax({
      url: url,
      type: 'POST',
      data: formData,
      async: false,
      success: function (result) {

        var dialog = new BootstrapDialog.show({
          message: 'Data has been edit..'
        });

        dialog.getModalHeader().css('color', '#fff');
        dialog.getModalHeader().css('background-color', '#337ab7');
        dialog.open();

        $('#haha').empty().html(result).fadeIn('slow');

      },
      cache: false,
      contentType: false,
      processData: false
    });

    return false;
  });



</script>













<script type="text/javascript">

  $('form#dataCryo').on('keyup keypress', function(e) {
    var keyCode = e.keyCode || e.which;
    if (keyCode === 13) { 
      e.preventDefault();
      return false;
    }
  });

  $('.form-control').keydown(function (e) {
   if (e.which === 13) {
     var index = $('.form-control').index(this) + 1;
     $('.form-control').eq(index).focus();
   }
 });

</script>






<script src="<?php echo base_url('assets/mask.js')?>"></script>







<script type="text/javascript">
  
  jQuery(function($){
   $("#ic").mask("999999-99-9999");
 });

</script>
















<script type="text/javascript">

  $('#ic').change(function() {

    $('#errorLocalId').empty();
    var ic = $('#ic').val();

    $.ajax({
      url : "<?php echo site_url('home/check_Ic_available')?>/",
      type: "POST",
      data: {
        "ic" : ic
      },    
      success: function(data)
      {
        if (data == 1)
        {
          $("#btnsubmit").prop("disabled", true);
          var dialog = new BootstrapDialog.show({
            message: 'Ic has been used..'
          });

          dialog.getModalHeader().css('color', '#fff');
          dialog.getModalHeader().css('background-color', '#337ab7');
          dialog.open();

        }
        else
        {
          $("#btnsubmit").removeAttr('disabled');

        }
      },
      error: function (jqXHR, textStatus, errorThrown)
      {
        alert('Error adding / update data');
      }
    });  
  });

</script>