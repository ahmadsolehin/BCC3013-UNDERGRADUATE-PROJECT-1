
<!DOCTYPE html>
<html>
<head>


	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/AdminLTE.min.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/skin-blue.min.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/bootstrap.min.css" />

	<meta charset="UTF-8">
	<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
	<!-- Bootstrap 3.3.2 -->

	<!-- Font Awesome Icons -->
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
	<!-- Ionicons -->
	<link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />

	<!-- jQuery 2.1.3 -->
	<script src="<?php echo base_url(); ?>assets/js/jQuery-2.1.3.min.js"></script>
	<!-- Bootstrap 3.3.2 JS -->
	<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js" type="text/javascript"></script>
	<!-- AdminLTE App -->


	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/prettify/r298/run_prettify.min.js"></script>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap3-dialog/1.34.9/css/bootstrap-dialog.min.css" rel="stylesheet" type="text/css" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap3-dialog/1.34.9/js/bootstrap-dialog.min.js"></script>


	<link href="<?php echo base_url('assets/css/bootstrap-datepicker3.min.css')?>" rel="stylesheet">
	<script src="<?php echo base_url('assets/js/bootstrap-datepicker.min.js')?>"></script>




<script type="text/javascript">

	$(document).off('change', '#ictekan').on('change', '#ictekan',function(e) {

					var ic = $('#ictekan').val();

					$.ajax({
						url : "<?php echo site_url('home/check_Ic_available')?>/",
						type: "POST",
						data: {
							"ic" : ic
						},    
						success: function(data)
						{
							if (data == 1)
							{
								$("#btnsubmit").prop("disabled", true);
								var dialog = new BootstrapDialog.show({
									message: 'Ic has been used..'
								});

								dialog.getModalHeader().css('color', '#fff');
								dialog.getModalHeader().css('background-color', '#337ab7');
								dialog.open();
  e.stopImmediatePropagation();//use to stop click twice or more

							}
							else
							{
								$("#btnsubmit").removeAttr('disabled');

							}
						},
						error: function (jqXHR, textStatus, errorThrown)
						{
							alert('Error adding / update data');
						}
					}); 
    }); 

</script>


</head>
<body class="hold-transition register-page">
	<div class="register-box">


		<div class="register-box-body">
			<p class="login-box-msg">Register a new membership</p>

			<?php 
			$fattr = array('class' => 'form-signin', 'id' => 'data');
			echo form_open('/home/register', $fattr); ?>

			<div class="form-group has-feedback">
				<?php echo form_input(array('name'=>'username', 'id'=> 'username', 'placeholder'=>'Username', 'class'=>'form-control', 'value' => set_value('username'))); ?>
				<?php echo form_error('username');?>
			</div>

			<div class="form-group has-feedback">
				<?php echo form_password(array('name'=>'password', 'id'=> 'password', 'placeholder'=>'Password', 'class'=>'form-control', 'value' => set_value('password'))); ?>
				<?php echo form_error('password');?>
			</div>

			<div class="form-group has-feedback">
				<?php echo form_input(array('name'=>'name', 'id'=> 'name', 'placeholder'=>'Name', 'class'=>'form-control', 'value' => set_value('name'))); ?>
				<?php echo form_error('name');?>
			</div>

			<div class="form-group has-feedback">
				<?php echo form_input(array('name'=>'ic', 'id'=> 'ictekan', 'placeholder'=>'Ic', 'class'=>'form-control', 'value'=> set_value('ic'))); ?>
				<?php echo form_error('ic');?>
			</div>

			<div class="form-group has-feedback">
				<?php echo form_input(array('name'=>'working', 'id'=> 'working', 'placeholder'=>'Working', 'class'=>'form-control', 'value'=> set_value('working'))); ?>
				<?php echo form_error('working');?>     
			</div>

			<div class="form-group has-feedback">
				<?php echo form_textarea(array('name'=>'address', 'id'=> 'address', 'placeholder'=>'Address', 'class'=>'form-control', 'value' => set_value('address'))); ?>
				<?php echo form_error('address') ?>
			</div>

			<div class="form-group has-feedback">
				<?php echo form_input(array('name'=>'house', 'id'=> 'house', 'placeholder'=>'house', 'class'=>'form-control', 'value'=> set_value('house'))); ?>
				<?php echo form_error('house');?>     
			</div>

			<div class="form-group has-feedback">
				<?php echo form_input(array('name'=>'office', 'id'=> 'office', 'placeholder'=>'office', 'class'=>'form-control', 'value' => set_value('office'))); ?>
				<?php echo form_error('office') ?>
			</div>

			<div class="form-group has-feedback">
				<?php echo form_input(array('name'=>'hp', 'id'=> 'hp', 'placeholder'=>'hp', 'class'=>'form-control', 'value'=> set_value('hp'))); ?>
				<?php echo form_error('hp');?>     
			</div>

			<div class="form-group has-feedback">
				<?php $options = array(
					'' => 'Select Gender',
					'Male'  => 'Male',
					'Female'    => 'Female',
					);
				$js = 'class="form-control" ';

				echo form_dropdown('gender', $options, '', $js);
				?>
				<?php echo form_error('gender') ?>
			</div>

			<div class="form-group has-feedback">

				<?php echo form_input(array('name'=>'dob', 'id'=> 'dob', 'placeholder'=>'date of birth', 'class'=>'form-control', 'value' => set_value('dob'))); ?>
				<?php echo form_error('dob') ?>
			</div>

			<div class="form-group has-feedback">
				<?php echo form_input(array('name'=>'nationality', 'id'=> 'nationality', 'placeholder'=>'nationality', 'class'=>'form-control', 'value'=> set_value('nationality'))); ?>
				<?php echo form_error('nationality');?>     
			</div>


			<div class="row">
				<div class="col-xs-4">
				</div><!-- /.col -->

				<div class="col-xs-4">

					<?php echo form_submit(array('value'=>'Sign up', 'id'=>'btnsubmit',  'class'=>'btn btn-primary btn-block btn-flat')); ?>
					<?php echo form_close(); ?>
				</div><!-- /.col -->

			</div>

		</div><!-- /.form-box -->
	</div><!-- /.register-box -->


</body>
</html>













<script type="text/javascript">
	
	jQuery(function($){
		$("#ictekan").mask("999999-99-9999");
	});

</script>



<script type="text/javascript">

	    //datepicker
	    $('#dob').datepicker({
	    	autoclose: true,
	    	format: "yyyy-mm-dd",
	    	todayHighlight: true,
	    	orientation: "top auto",
	    	todayBtn: true,
	    	todayHighlight: true,  
	    });

	</script>

	<script src="<?php echo base_url('assets/mask.js')?>"></script>









	<script type="text/javascript">

		$('form#data').on('keyup keypress', function(e) {
			var keyCode = e.keyCode || e.which;
			if (keyCode === 13) { 
				e.preventDefault();
				return false;
			}
		});

		$('.form-control').keydown(function (e) {
			if (e.which === 13) {
				var index = $('.form-control').index(this) + 1;
				$('.form-control').eq(index).focus();
			}
		});

	</script>




