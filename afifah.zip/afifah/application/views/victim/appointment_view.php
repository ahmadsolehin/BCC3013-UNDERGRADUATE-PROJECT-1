    <link href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/datatables/css/dataTables.bootstrap.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/bootstrap-datepicker/css/bootstrap-datepicker3.min.css')?>" rel="stylesheet">

<script src="<?php echo base_url('assets/jquery/jquery-2.1.4.min.js')?>"></script>
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js')?>"></script>
<script src="<?php echo base_url('assets/datatables/js/jquery.dataTables.min.js')?>"></script>
<script src="<?php echo base_url('assets/datatables/js/dataTables.bootstrap.js')?>"></script>
<script src="<?php echo base_url('assets/bootstrap-datepicker/js/bootstrap-datepicker.min.js')?>"></script>


<div class = "row">


<div class="col-md-12">
        <br />

<button class="btn btn-success" onclick="add_report()"><i class="glyphicon glyphicon-plus"></i> Add New Appointment</button>

</br>
</br>
<table class="table table-bordered table-hover">
	<thead>
		<tr>
			<th width="50px">Code</th>
			<th width="125px">Name</th>
			<th width="125px">Date</th>
			<th width="125px">Time</th>
			<th width="125px">Police station</th>
			<th width="125px">Status</th>
			<th width="125px">Action</th>
		</tr>
	</thead>
	<tbody class = "tab_loc"></tbody>
</table>
</div>



</div>




<script type="text/javascript">

    //datepicker
    $('.datepicker').datepicker({
        autoclose: true,
        format: "yyyy-mm-dd",
        todayHighlight: true,
        orientation: "top auto",
        todayBtn: true,
        todayHighlight: true,  
    });

var id = <?php echo $this->session->userdata('id');?>;

     //nie utk dropdown location 
     $(document).ready(function(){

     	$('.tab_loc').empty();

     	$.ajax({
     		url : "<?php echo site_url('victim/appointment/list_appointment')?>/",
     		type: "POST",
     		data: {
     			id : id
     		      	},
     		dataType: "JSON",
     		success: function(json_data)
     		{

     			for (var i = 0; i < json_data.length; i++) {

                            //alert(json_data[i].id);
                            var a = '<tr><td>'+json_data[i].id+'</td><td>'+json_data[i].name+'</td>   <td>'+json_data[i].date+'</td>     <td>'+json_data[i].time+'</td>  <td>'+json_data[i].police_station+'</td>    <td>'+json_data[i].status+'</td>        <td><a class="btn btn-warning btn-sm" onclick = "editReport('+json_data[i].id+')"> <span class="glyphicon glyphicon-pencil" aria-hidden="true"> </span> </a>     <a class="btn btn-danger btn-sm"  onclick="DeleteReport('+json_data[i].id+')" ><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a> <a class="btn btn-default btn-sm" onclick = "viewReport('+json_data[i].id+')"> <span class="glyphicon glyphicon-file" aria-hidden="true"> </span> </a>  </td> </tr>';
                            $('.tab_loc').append(a);
                        }

                    },
                    error: function (jqXHR, textStatus, errorThrown)
                    {
                    	alert('Error adding / update data');
                    }
                });
     })






function add_report()
{
	save_method = 'add';
      $('#form')[0].reset(); // reset form on modals
      $('#modal_form').modal('show'); // show bootstrap modal
      $('.modal-title').text('Add New Appointment'); // Set Title to Bootstrap modal title
  }


  function editReport(id)
  {
    $.ajax({
        url : "<?php echo site_url('victim/appointment/ajax_edit/')?>/" + id,
      type: "GET",
        success: function(result)
        {
         $('#haha').empty().html(result).fadeIn('slow');
       },
       error: function (jqXHR, textStatus, errorThrown)
       {
        alert('Error get data from ajax');
      }
    });
  }

function save()
{
    $('#btnSave').text('saving...'); //change button text
    $('#btnSave').attr('disabled',true); //set button disable 
    var url;

    if(save_method == 'add') {
        url = "<?php echo site_url('victim/appointment/ajax_add')?>/" + id;
    } else {
        url = "<?php echo site_url('victim/appointment/ajax_update')?>/" + id;
    }

    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: $('#form').serialize(),
        dataType: "JSON",
        success: function(data)
        {
            $('#modal_form').modal('hide');
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
            loadList();
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 

        }
    });
}

function DeleteReport(id)
{
    if(confirm('Are you sure delete this data?'))
    {
        // ajax delete data to database
        $.ajax({
            url : "<?php echo site_url('victim/appointment/ajax_delete/')?>/" + id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
                loadList();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error deleting data');
            }
        });

    }
}

function viewReport(id)
{
     // ajax adding data to database
          $.ajax({
            url : "<?php echo site_url('victim/appointment/list_appointment_by_id')?>/" + id,
            type: "GET",
            success: function(result)
            {
                $('#haha').empty().html(result).fadeIn('slow');
            },
            error: function (jqXHR, textStatus, errorThrown)
            {

            }
        });
}



</script>











<!-- Bootstrap modal -->
<div class="modal fade" id="modal_form" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title"> Form</h3>
            </div>
            <div class="modal-body form">
                <form action="#" id="form" class="form-horizontal">
                    <input type="hidden" value="" name="id"/> 
                    <div class="form-body">
                        <div class="form-group">
                            <label class="control-label col-md-3">Name</label>
                            <div class="col-md-9">
                                <input name="name" value = "<?php echo $this->session->userdata('name');?>"  placeholder="Name" class="form-control" type="text">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3">Location</label>
                            <div class="col-md-9">
                                <select id = "location" name="location" class="form-control">
                                    <option value="">--Select--</option>
                                    <option value="KUANTAN">KUANTAN</option>
                                    <option value="BENTONG">BENTONG</option>
                                    <option value="BERA">BERA</option>
                                    <option value="CAMERON">CAMERON HIGHLAND</option>
                                    <option value="JERANTUT">JERANTUT</option>
                                    <option value="LIPIS">KUALA LIPIS</option>
                                    <option value="MARAN">MARAN</option>
                                    <option value="PEKAN">PEKAN</option>
                                    <option value="RAUB">RAUB</option>
                                    <option value="ROMPIN">ROMPIN</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3">Police Station</label>
                            <div class="col-md-9">
                                <textarea id = "polis" name="polis" placeholder="explaination" class="form-control"></textarea>
                            </div>
                        </div>

                        <div class="form-group">
                        <label class="control-label col-md-3">Reason</label>
                        	<div class="col-md-9">
                        		<input name="reason" placeholder="reason" class="form-control" type="text">
                        	</div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3">Date</label>
                            <div class="col-md-9">
                                <input name="date" placeholder="yyyy-mm-dd" class="form-control datepicker" type="text">
                            </div>
                        </div>

                         <div class="form-group">
                        <label class="control-label col-md-3">Time</label>
                        	<div class="col-md-9">
                        		<input name="time" placeholder="time" class="form-control" type="text">
                        	</div>
                        </div>

                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- End Bootstrap modal -->





<script type="text/javascript">
    

 $(document).on('change','#location',function(){

        if($(this).val() == "KUANTAN")
            {
                $('#polis').empty().append('Ibupejabat Polis Daerah Kuantan Polis Diraja Malaysia Jalan Mahkota 25000 Kuantan, Pahang.');
            }
            else if($(this).val() == "BENTONG")
            {
                $('#polis').empty().append('Ibupejabat Polis Daerah Bentong Jalan Anuar Polis Diraja Malaysia 28700 Bentong, Pahang');
            }
            else if($(this).val() == "CAMERON")
            {
                $('#polis').empty().append('Ibupejabat Polis Daerah Cameron Highland Tanah Rata Polis Diraja Malaysia 39000 Pahang.');
            }
            else if($(this).val() == "JERANTUT")
            {
                $('#polis').empty().append('Ibupejabat Polis Daerah Jerantut Polis Diraja Malaysia 27000 Jerantut,Pahang.');
            }
            else if($(this).val() == "LIPIS")
            {
                $('#polis').empty().append('Ibupejabat Polis Daerah Kuala Lipis Polis Diraja Malaysia 27200 Kuala Lipis Pahang.');
            }
            else if($(this).val() == "MARAN")
            {
                $('#polis').empty().append('Ibupejabat Polis Daerah Maran Polis Diraja Malaysia 26500 Maran,Pahang.');
            }
            else if($(this).val() == "PEKAN")
            {
                $('#polis').empty().append('Ibupejabat Polis Daerah Daerah Pekan Polis Diraja Malaysia 26600 Pekan, Pahang.');
            }
            else if($(this).val() == "RAUB")
            {
                $('#polis').empty().append('Ibupejabat Polis Daerah Daerah Raub Polis Diraja Malaysia 27600 Raub Pahang');
            }
            else if($(this).val() == "ROMPIN")
            {
                $('#polis').empty().append('Ibupejabat Polis Daerah Rompin Polis Diraja Malaysia 26800 K. Rompin,Rompin, Pahang.');
            }
            else if($(this).val() == "BERA")
            {
                $('#polis').empty().append('Ibupejabat Polis Daerah Bera Polis Diraja Malaysia 28300, Bera.');
            }
        });


</script>



<script type="text/javascript">
    function loadList()
    {
        var id = <?php echo $this->session->userdata('id');?>;

     //nie utk dropdown location 
     $(document).ready(function(){

        $('.tab_loc').empty();

        $.ajax({
            url : "<?php echo site_url('victim/appointment/list_appointment')?>/",
            type: "POST",
            data: {
                id : id
                    },
            dataType: "JSON",
            success: function(json_data)
            {

                for (var i = 0; i < json_data.length; i++) {

                            //alert(json_data[i].id);
                            var a = '<tr><td>'+json_data[i].id+'</td><td>'+json_data[i].name+'</td>   <td>'+json_data[i].date+'</td>     <td>'+json_data[i].time+'</td>  <td>'+json_data[i].police_station+'</td>    <td>'+json_data[i].status+'</td>        <td><a class="btn btn-warning btn-sm" onclick = "editReport('+json_data[i].id+')"> <span class="glyphicon glyphicon-pencil" aria-hidden="true"> </span> </a>     <a class="btn btn-danger btn-sm"  onclick="DeleteReport('+json_data[i].id+')" ><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a> <a class="btn btn-default btn-sm" onclick = "viewReport('+json_data[i].id+')"> <span class="glyphicon glyphicon-file" aria-hidden="true"> </span> </a>  </td> </tr>';
                            $('.tab_loc').append(a);
                        }

                    },
                    error: function (jqXHR, textStatus, errorThrown)
                    {
                        alert('Error adding / update data');
                    }
                });
     })
    }
</script>