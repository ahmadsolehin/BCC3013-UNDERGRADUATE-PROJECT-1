    <link href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/datatables/css/dataTables.bootstrap.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/bootstrap-datepicker/css/bootstrap-datepicker3.min.css')?>" rel="stylesheet">

<script src="<?php echo base_url('assets/jquery/jquery-2.1.4.min.js')?>"></script>
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js')?>"></script>
<script src="<?php echo base_url('assets/datatables/js/jquery.dataTables.min.js')?>"></script>
<script src="<?php echo base_url('assets/datatables/js/dataTables.bootstrap.js')?>"></script>
<script src="<?php echo base_url('assets/bootstrap-datepicker/js/bootstrap-datepicker.min.js')?>"></script>


<div class = "row">


<div class="col-md-12">
        <br />

<button class="btn btn-success" onclick="add_report()"><i class="glyphicon glyphicon-plus"></i> Add New Report</button>

</br>
</br>
<table class="table table-bordered table-hover">
	<thead>
		<tr>
			<th width="50px">Code</th>
			<th width="125px">Name</th>
			<th width="125px">Type of Crime</th>
			<th width="125px">Date</th>
			<th width="125px">Location</th>
			<th width="125px">Status</th>
			<th width="125px">Action</th>
		</tr>
	</thead>
	<tbody class = "tab_loc"></tbody>
</table>
</div>



</div>




<script type="text/javascript">

    //datepicker
    $('.datepicker').datepicker({
        autoclose: true,
        format: "yyyy-mm-dd",
        todayHighlight: true,
        orientation: "top auto",
        todayBtn: true,
        todayHighlight: true,  
    });

    var id = <?php echo $this->session->userdata('id');?>;

     //nie utk dropdown location 
     $(document).ready(function(){

     	$('.tab_loc').empty();

     	$.ajax({
     		url : "<?php echo site_url('victim/report/list_report')?>/",
     		type: "POST",
     		data: {
     			id : id
          },
          dataType: "JSON",
          success: function(json_data)
          {

            for (var i = 0; i < json_data.length; i++) {

                            //alert(json_data[i].id);
                            var a = '<tr><td>'+json_data[i].id+'</td><td>'+json_data[i].name+'</td>   <td>'+json_data[i].type_of_crime+'</td>     <td>'+json_data[i].date+'</td>  <td>'+json_data[i].location+'</td>    <td>'+json_data[i].status+'</td>        <td><a class="btn btn-warning btn-sm" onclick = "editReport('+json_data[i].id+')"> <span class="glyphicon glyphicon-pencil" aria-hidden="true"> </span> </a>     <a class="btn btn-danger btn-sm"  onclick="DeleteReport('+json_data[i].id+')" ><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>     <a class="btn btn-default btn-sm" onclick = "viewReport('+json_data[i].id+')"> <span class="glyphicon glyphicon-file" aria-hidden="true"> </span> </a></td></tr>';
                            $('.tab_loc').append(a);
                        }

                    },
                    error: function (jqXHR, textStatus, errorThrown)
                    {
                    	alert('Error adding / update data');
                    }
                });
})






    function add_report()
    {
       save_method = 'add';
      $('#form')[0].reset(); // reset form on modals
      $('#modal_form').modal('show'); // show bootstrap modal
      $('.modal-title').text('Add New Report'); // Set Title to Bootstrap modal title
  }

  function editReport(id)
  {
    save_method = 'update';
    $('#form')[0].reset(); // reset form on modals

    $.ajax({
        url : "<?php echo site_url('victim/report/ajax_edit/')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="id"]').val(data.id);
            $('[name="userId"]').val(data.userId);
            $('[name="name"]').val(data.name);
            $('[name="typeofcrime"]').val(data.type_of_crime);
            $('[name="location"]').val(data.location);
            $('[name="date"]').datepicker('update',data.date);
            $('[name="explaination"]').val(data.explaination);
            $('[name="time"]').val(data.time);
            $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit Report'); // Set title to Bootstrap modal title

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}

function DeleteReport(id)
{
    if(confirm('Are you sure delete this data?'))
    {
        // ajax delete data to database
        $.ajax({
            url : "<?php echo site_url('victim/report/ajax_delete/')?>/" + id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
                loadList();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error deleting data');
            }
        });

    }
}

function save()
{
    $('#btnSave').text('saving...'); //change button text
    $('#btnSave').attr('disabled',true); //set button disable 
    var url;

    if(save_method == 'add') {
        url = "<?php echo site_url('victim/report/ajax_add')?>/" + id;
    } else {
        url = "<?php echo site_url('victim/report/ajax_update')?>/" + id;
    }

    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: $('#form').serialize(),
        dataType: "JSON",
        success: function(data)
        {

            $('#modal_form').modal('hide');
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
            loadList();

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 

        }
    });
}

function viewReport(id)
{
          // ajax adding data to database
          $.ajax({
            url : "<?php echo site_url('victim/report/list_report_by_id')?>/" + id,
            type: "GET",
            success: function(result)
            {
                $('#haha').empty().html(result).fadeIn('slow');
            },
            error: function (jqXHR, textStatus, errorThrown)
            {

            }
        });
      }



  </script>











<!-- Bootstrap modal -->
<div class="modal fade" id="modal_form" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title"> Form</h3>
            </div>
            <div class="modal-body form">
                <form action="#" id="form" class="form-horizontal">
                    <input type="hidden" value="" name="id"/> 
                    <input type="hidden" value="" name="userId"/> 
                    <div class="form-body">
                        <div class="form-group">
                            <label class="control-label col-md-3">Name</label>
                            <div class="col-md-9">
                                <input name="name" value = "<?php echo $this->session->userdata('name');?>" placeholder="Name" class="form-control" type="text">
                            </div>
                        </div>


                        <div class="form-group">
                            <label class="control-label col-md-3">Type of Crime</label>
                            <div class="col-md-9">
                                <select name="typeofcrime" class="form-control">
                                    <option value="">--Select--</option>
                                    <option value="Bully">Bully</option>
                                    <option value="Cyber Crime">Cyber Crime</option>
                                    <option value="Thief">Thief</option>
                                    <option value="Drunkenness">Drunkenness</option>
                                    <option value="Prostitution">Prostitution</option>
                                    <option value="Blackmail">Blackmail</option>
                                    <option value="Juvenile cases">Juvenile cases</option>
                                    <option value="Roadbully">Road Bully</option>
                                    <option value="Abuse">Abuse</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                        <label class="control-label col-md-3">Location</label>
                        	<div class="col-md-9">
                        		<input name="location" placeholder="location" class="form-control" type="text">
                        	</div>
                        </div>


                        <div class="form-group">
                            <label class="control-label col-md-3">Explaination</label>
                            <div class="col-md-9">
                                <textarea name="explaination" placeholder="explaination" class="form-control"></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Date</label>
                            <div class="col-md-9">
                                <input name="date" placeholder="yyyy-mm-dd" class="form-control datepicker" type="text">
                            </div>
                        </div>

                         <div class="form-group">
                        <label class="control-label col-md-3">Time</label>
                        	<div class="col-md-9">
                        		<input name="time" placeholder="time" class="form-control" type="text">
                        	</div>
                        </div>

                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- End Bootstrap modal -->

















<script type="text/javascript">
    function loadList()
    {
            var id = <?php echo $this->session->userdata('id');?>;

     //nie utk dropdown location 
     $(document).ready(function(){

        $('.tab_loc').empty();

        $.ajax({
            url : "<?php echo site_url('victim/report/list_report')?>/",
            type: "POST",
            data: {
                id : id
          },
          dataType: "JSON",
          success: function(json_data)
          {

            for (var i = 0; i < json_data.length; i++) {

                            //alert(json_data[i].id);
                            var a = '<tr><td>'+json_data[i].id+'</td><td>'+json_data[i].name+'</td>   <td>'+json_data[i].type_of_crime+'</td>     <td>'+json_data[i].date+'</td>  <td>'+json_data[i].location+'</td>    <td>'+json_data[i].status+'</td>        <td><a class="btn btn-warning btn-sm" onclick = "editReport('+json_data[i].id+')"> <span class="glyphicon glyphicon-pencil" aria-hidden="true"> </span> </a>     <a class="btn btn-danger btn-sm"  onclick="DeleteReport('+json_data[i].id+')" ><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>     <a class="btn btn-default btn-sm" onclick = "viewReport('+json_data[i].id+')"> <span class="glyphicon glyphicon-file" aria-hidden="true"> </span> </a></td></tr>';
                            $('.tab_loc').append(a);
                        }

                    },
                    error: function (jqXHR, textStatus, errorThrown)
                    {
                        alert('Error adding / update data');
                    }
                });
})
    }
</script>